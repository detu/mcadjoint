//
// Created by Stefano Weidmann on 17.05.18.
//

#pragma once


static constexpr bool doTryToCorrectForGrowth = false;
static constexpr bool onlyCorrectPressurePart = true;
