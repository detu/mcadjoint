//
// Created by Stefano Weidmann on 18.05.18.
//

#pragma once
constexpr bool useFixedTimestep = true;