//
// Created by Stefano Weidmann on 17.05.18.
//

#pragma once
#include "preconditioning.hpp"
const WhichPreconditioner preconditionerToUse = WhichPreconditioner::PRESSURE_BY_PRESSURE;
constexpr bool startAddingRandomWalksAtBeginning = true;

