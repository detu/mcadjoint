//
// Created by Stefano Weidmann on 17.05.18.
//

#pragma once
#include <vector>
#include "typedefs.hpp"

int pickAnIndex(const std::vector<Real>& weights, const Real standardUniformRV);