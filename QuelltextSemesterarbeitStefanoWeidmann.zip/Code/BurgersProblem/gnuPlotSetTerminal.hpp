//
// Created by Stefano Weidmann on 04.03.18.
//

#ifndef MCADJOINT_GNUPLOTSETTERMINAL_HPP
#define MCADJOINT_GNUPLOTSETTERMINAL_HPP

#include "gnuplot_i.h"

void setTerminal(Gnuplot& g);

#endif //MCADJOINT_GNUPLOTSETTERMINAL_HPP
