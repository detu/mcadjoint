//
// Created by Stefano Weidmann on 13.03.18.
//

#ifndef MCADJOINT_UTILS_HPP
#define MCADJOINT_UTILS_HPP
#include <string>
std::string lowerCase(std::string str);

#endif //MCADJOINT_UTILS_HPP
