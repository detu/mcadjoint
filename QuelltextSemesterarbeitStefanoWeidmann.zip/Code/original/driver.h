//
//  driver.h
//  Adjoint-MC
//
//  Created by Patrick Jenny on 14/02/18.
//  Copyright © 2018 Patrick Jenny. All rights reserved.
//

#ifndef driver_h
#define driver_h

class Driver {
public:
  void solve_Burger ();
//void solve_NS     ();
};

#endif /* driver_h */
